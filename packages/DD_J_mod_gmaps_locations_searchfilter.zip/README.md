# DD_J_mod_gmaps_locations_searchfilter
A Joomla! module to display search and filter for DD Google Maps Locations. Addon Module for DD Gmaps Locations https://github.com/hr-it-solutions/DD_J_com_gmaps_locations. Module can NOT be used as stand alone module. 

[![GPL Licence](https://badges.frapsoft.com/os/gpl/gpl.png?v=102)](https://opensource.org/licenses/GPL-2.0/)

- Geolocalisation function
- Google search suggestions
- Location category filter
- Full-text search

# System requirements
Joomla 3.6 +                                                                                <br>
PHP 5.6.13 or newer is recommended.

# DD_ Namespace
DD_ stands for  **D**idl**d**u e.K. | HR IT-Solutions (Brand recognition)                   <br>
It is a namespace prefix, provided to avoid element name conflicts.

<br>
Author: HR IT-Solutions Florian Häusler https://www.hr-it-solution.com                      <br>
Copyright: (C) 2011 - 2019 HR-IT-Solutions GmbH                                    <br>
http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
