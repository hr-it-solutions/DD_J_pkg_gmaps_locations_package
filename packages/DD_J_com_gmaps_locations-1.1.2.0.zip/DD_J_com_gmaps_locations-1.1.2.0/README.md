# DD_J_com_gmaps_locations
An extendable Joomla! component for integrating Google Maps Locations.
Location entries, location profile pages, location search, geolocation search, Google Maps module, customization options, etc… More than just maps: A reliable extension for building your own plattform or community based on Google Maps.

[![GPL Licence](https://badges.frapsoft.com/os/gpl/gpl.png?v=102)](https://opensource.org/licenses/GPL-2.0/)

**Note:** These is just the **Community-Editon Repository** of the component itself, not the required component packag!.<br>
For getting component package, more infos, description, PRO-Version, licensing and ordering, please visit our product hompage.

### Get  [**🔗 More Infos...**](https://www.hr-it-solutions.com/extension-shop/joomla-extensions/4/gmaps-locations)
[**https://www.hr-it-solutions.com/extension-shop/joomla-extensions/4/gmaps-locations**](https://www.hr-it-solutions.com/extension-shop/joomla-extensions/4/gmaps-locations)

# DD_ Namespace
DD_ is a namespace prefix of the **HR-IT-Solutions GmbH**, provided to avoid element name conflicts.

<br>
Author: HR-IT-Solutions GmbH Florian Häusler https://www.hr-it-solution.com <br>
Copyright: (C) 2017 - 2019 HR-IT-Solutions GmbH <br>
http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
