# DD_J_mod_gmaps_module
 A Joomla! module to display Google Maps. Addon Module for DD Gmaps Locations https://github.com/hr-it-solutions/DD_J_com_gmaps_locations. Module can also be used as stand alone module.

[![GPL Licence](https://badges.frapsoft.com/os/gpl/gpl.png?v=102)](https://opensource.org/licenses/GPL-2.0/)

#### Main Features
- Google Maps module
- Map in Popup (full size PopUp)
- Validate a single addresses via the backend (geocoding of the address)
- Google Maps v3 integration (API key connection possible) Integrated Google JavaScript API and Geocoding API
- Adjustable map size, position and zoom level
- Support all major web browsers

##### Addon Features for DD Gmaps Locations Component
- Locations Linked to the map
- Profile pages liked to the map
- Extends list layout to display multiple locations

**and much more...**

# System requirements
Joomla 3.6 +                                                                                <br>
PHP 5.6.13 or newer is recommended.

# DD_ Namespace
DD_ stands for  **D**idl**d**u e.K. | HR IT-Solutions (Brand recognition)                   <br>
It is a namespace prefix, provided to avoid element name conflicts.

<br>
Author: HR IT-Solutions Florian Häusler https://www.hr-it-solution.com                      <br>
Copyright: (C) 2011 - 2017 Didldu e.K. | HR IT-Solutions                                    <br>
http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
