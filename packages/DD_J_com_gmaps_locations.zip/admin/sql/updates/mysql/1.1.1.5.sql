-- DD GMAPS LOCATIONS table SQL script
-- This will update all the the tables to run DD GMAPS LOCATIONS

--
-- Table structure for table `#__dd_gmaps_locations`
--

ALTER TABLE `#__dd_gmaps_locations` ADD `ext_c_id` int(1) unsigned NOT NULL AFTER `ll_c`;